import { ArrowRight, Rocket, Users, TrendingUp, Lightbulb } from 'lucide-react'

const benefits = [
  { icon: Lightbulb, title: 'Structure your project', description: 'Define your business model and strategy' },
  { icon: Users, title: 'Access mentorship', description: 'Learn from experienced entrepreneurs' },
  { icon: TrendingUp, title: 'Connect with investors', description: 'Pitch to our network of investors' },
]

export function IncubatorCtaSection() {
  return (
    <section className="py-20 lg:py-32 relative overflow-hidden" style={{ backgroundColor: 'var(--background)' }}>
      <div className="absolute top-0 left-0 w-full h-px" style={{ background: 'linear-gradient(to right, transparent, color-mix(in oklch, var(--primary) 30%, transparent), transparent)' }} />
      <div className="absolute bottom-0 left-0 w-full h-px" style={{ background: 'linear-gradient(to right, transparent, color-mix(in oklch, var(--primary) 30%, transparent), transparent)' }} />
      <div className="absolute top-1/2 right-0 w-96 h-96 rounded-full blur-3xl -translate-y-1/2" style={{ backgroundColor: 'color-mix(in oklch, var(--primary) 5%, transparent)' }} />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <div
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border text-sm font-medium mb-6"
              style={{ borderColor: 'color-mix(in oklch, var(--primary) 30%, transparent)', backgroundColor: 'color-mix(in oklch, var(--primary) 10%, transparent)', color: 'var(--primary)' }}
            >
              <Rocket className="h-4 w-4" />
              Programme Phare
            </div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight" style={{ color: 'var(--foreground)' }}>
              Join our <span style={{ color: 'var(--primary)' }}>incubation program</span>
            </h2>
            <p className="mt-6 text-lg leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
              Support for entrepreneurs to structure, develop and launch their projects. Get the resources, mentorship and network you need to turn your idea into a successful business.
            </p>
            <div className="mt-10 grid gap-6">
              {benefits.map((benefit) => (
                <div key={benefit.title} className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'color-mix(in oklch, var(--primary) 10%, transparent)' }}>
                    <benefit.icon className="h-6 w-6" style={{ color: 'var(--primary)' }} />
                  </div>
                  <div>
                    <h3 className="font-semibold" style={{ color: 'var(--foreground)' }}>{benefit.title}</h3>
                    <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-10">
              <a
                href="https://wa.me/237600000000?text=Bonjour, je souhaite postuler à l'incubateur Malea Hub"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-lg text-base font-semibold transition-opacity hover:opacity-90"
                style={{ backgroundColor: 'var(--primary)', color: 'var(--primary-foreground)' }}
              >
                Apply now <ArrowRight className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl p-8 lg:p-10 relative overflow-hidden border" style={{ backgroundColor: 'var(--card)', borderColor: 'color-mix(in oklch, var(--primary) 20%, transparent)' }}>
              <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 rounded-tl-2xl" style={{ borderColor: 'color-mix(in oklch, var(--primary) 40%, transparent)' }} />
              <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 rounded-br-2xl" style={{ borderColor: 'color-mix(in oklch, var(--primary) 40%, transparent)' }} />
              <div className="text-center">
                <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: 'color-mix(in oklch, var(--primary) 10%, transparent)' }}>
                  <Rocket className="h-10 w-10" style={{ color: 'var(--primary)' }} />
                </div>
                <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--foreground)' }}>Incubateur Malea Hub</h3>
                <p className="leading-relaxed mb-8" style={{ color: 'var(--muted-foreground)' }}>
                  From idea to launch, we support innovative projects with high growth potential in Cameroon and across Africa.
                </p>
                <div className="grid grid-cols-2 gap-4 text-left">
                  {[
                    { value: '3', label: 'months program' },
                    { value: '10+', label: 'mentors' },
                    { value: '5', label: 'startups / cohort' },
                    { value: 'Demo', label: 'day with investors' },
                  ].map((item) => (
                    <div key={item.label} className="rounded-lg p-4 border" style={{ backgroundColor: 'color-mix(in oklch, var(--background) 50%, transparent)', borderColor: 'color-mix(in oklch, var(--border) 50%, transparent)' }}>
                      <div className="text-2xl font-bold" style={{ color: 'var(--primary)' }}>{item.value}</div>
                      <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{item.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 w-24 h-24 border rounded-2xl -z-10" style={{ borderColor: 'color-mix(in oklch, var(--primary) 20%, transparent)' }} />
            <div className="absolute -top-4 -left-4 w-16 h-16 rounded-xl -z-10" style={{ backgroundColor: 'color-mix(in oklch, var(--primary) 10%, transparent)' }} />
          </div>
        </div>
      </div>
    </section>
  )
}
