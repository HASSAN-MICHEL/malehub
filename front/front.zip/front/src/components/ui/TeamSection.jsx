import { useTranslation } from 'react-i18next';

export function TeamSection() {
  const { t } = useTranslation();
  
  // Membres avec images directement dans le composant
  const members = [
    {
      name: "Erdman Doumbè",
      role: "Fondateur & CEO",
      image: "/maleblan.jpeg"
    },
    {
      name: "Sarah Kamga",
      role: "Directrice des Programmes",
      image: "maleannonce.jpeg"
    },
    {
      name: "Michael Tchouta",
      role: "Lead Mentor",
      image: "maletravail.jpeg"
    },
    {
      name: "Amira Diallo",
      role: "Community Manager",
      image: "malenoir.jpeg"
    },
    {
      name: "Jean Njiké",
      role: "Chargé d'Incubation",
      image: "malesalon.jpeg"
    },
    {
      name: "Clarisse Ngo",
      role: "Formatrice certifiée",
      image: "maleSalonthe.jpeg"
    }
  ];
  
  // Dupliquer les membres pour un effet de boucle infinie
  const duplicatedMembers = [...members, ...members, ...members];

  return (
    <section className="py-12 lg:py-16" style={{ backgroundColor: 'var(--background)' }}>
      <div className="container mx-auto px-4 lg:px-8">
        {/* En-tête plus compact */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          {/* Badge "Notre équipe" - plus grand, texte noir */}
          <div
            className="inline-flex items-center gap-3 px-6 py-3 rounded-full border text-lg md:text-xl font-medium mb-4"
            style={{ 
               color: '#000000' ,  backgroundColor: 'var(--primary)', color: 'var(--primary-foreground)' 
            }}
          >
            {t('team.badge')}
          </div>
          
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold leading-tight" style={{ color: 'var(--foreground)' }}>
            {t('team.title_prefix')}{' '}
            <span style={{ color: 'var(--primary)' }}>{t('team.title_highlight')}</span>
          </h2>
          <p className="mt-3 text-base leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
            {t('team.subtitle')}
          </p>
        </div>

        {/* Marquee avec CSS pur */}
        <div className="relative overflow-hidden">
          <div className="animate-marquee flex gap-6 lg:gap-8">
            {duplicatedMembers.map((member, index) => (
              <div
                key={`${member.name}-${index}`}
                className="flex-shrink-0 w-28 lg:w-36"
              >
                <div className="text-center">
                  {/* Photo en cercle - taille réduite */}
                  <div className="relative mx-auto mb-3">
                    <div className="w-20 h-20 lg:w-28 lg:h-28 rounded-full overflow-hidden border-2 transition-all duration-300 hover:scale-105 hover:shadow-md mx-auto"
                      style={{
                        borderColor: 'color-mix(in oklch, var(--primary) 40%, transparent)',
                        backgroundColor: 'var(--card)'
                      }}
                    >
                      <img
                        src={member.image}
                        alt={member.name}
                        className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                        onError={(e) => {
                          e.currentTarget.src = 'https://via.placeholder.com/150?text=Photo';
                        }}
                      />
                    </div>
                  </div>
                  
                  {/* Informations du membre - seulement nom et fonction */}
                  <div>
                    <h3 className="text-xs lg:text-sm font-bold mb-0.5" style={{ color: 'var(--foreground)' }}>
                      {member.name}
                    </h3>
                    <p className="text-[10px] lg:text-xs font-medium" style={{ color: 'var(--primary)' }}>
                      {member.role}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Styles CSS pour l'animation marquee */}
      <style>{`
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-33.33%);
          }
        }
        
        .animate-marquee {
          animation: marquee 25s linear infinite;
          width: fit-content;
        }
        
        .animate-marquee:hover {
          animation-play-state: paused;
        }
        
        /* Cache la scrollbar */
        .overflow-hidden {
          overflow: hidden;
        }
      `}</style>
    </section>
  );
}